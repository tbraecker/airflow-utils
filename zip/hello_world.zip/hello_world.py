class hello_world_class:
    def output():
        print('hello world')

    def output_2():
        print('hello world 2')
